import { NativeEventEmitter, NativeModules, Platform } from "react-native";

type SingboxNativeModule = {
  connect(config: string): Promise<"started" | "permission_required">;
  disconnect(): Promise<void>;
  status(): Promise<boolean>;
};

const native = NativeModules.IbrahimSingbox as SingboxNativeModule | undefined;

export const singboxNative = {
  available: Platform.OS === "android" && Boolean(native),
  connect: (config: string) => native?.connect(config) ?? Promise.reject(new Error("محرك VPN الأصلي غير متاح")),
  disconnect: () => native?.disconnect() ?? Promise.resolve(),
  status: () => native?.status() ?? Promise.resolve(false),
};

/**
 * يحول روابط V2Ray الشائعة إلى إعداد sing-box كامل مع TUN.
 * هذه الطبقة لا تعتبر الرابط صالحًا حتى تنتج إعدادًا يمكن للنواة تحليله.
 */
export function proxyToSingboxConfig(input: string): string {
  const clean = input.trim();
  if (!clean) throw new Error("إعداد السيرفر فارغ");
  const outbound = parseOutbound(clean);
  return JSON.stringify({
    log: { level: "warn" },
    dns: {
      servers: [{ tag: "remote", address: "https://1.1.1.1/dns-query", detour: "proxy" }],
      final: "remote",
      strategy: "prefer_ipv4",
    },
    inbounds: [{
      type: "tun",
      tag: "tun-in",
      interface_name: "ibrahim-tun",
      address: ["172.19.0.1/30", "fdfe:dcba:9876::1/126"],
      auto_route: true,
      strict_route: true,
      stack: "system",
    }],
    outbounds: [outbound, { type: "direct", tag: "direct" }, { type: "block", tag: "block" }],
    route: { auto_detect_interface: true, final: "proxy" },
  });
}

// Backwards-compatible name used by older callers.
export const vlessToSingboxConfig = proxyToSingboxConfig;

function parseOutbound(input: string): Record<string, unknown> {
  if (input.startsWith("vless://")) return parseVless(input);
  if (input.startsWith("vmess://")) return parseVmess(input);
  if (input.startsWith("trojan://")) return parseTrojan(input);
  if (input.startsWith("ss://")) return parseShadowsocks(input);
  if (input.startsWith("socks5://") || input.startsWith("socks://")) return parseSocks(input);
  if (input.startsWith("http://") || input.startsWith("https://")) return parseHttp(input);
  throw new Error("الصيغة غير مدعومة للنواة: استخدم رابط VLESS أو VMess أو Trojan أو SS أو SOCKS أو HTTP");
}

function baseTls(params: URLSearchParams, host: string, defaultEnabled = false) {
  const security = params.get("security") ?? (defaultEnabled ? "tls" : "none");
  if (security !== "tls" && security !== "reality") return { enabled: false };
  const tls: Record<string, unknown> = {
    enabled: true,
    server_name: params.get("sni") ?? params.get("host") ?? host,
    alpn: params.get("alpn")?.split(",").filter(Boolean),
    utls: { enabled: true, fingerprint: params.get("fp") ?? "chrome" },
  };
  if (security === "reality") {
    tls.reality = { enabled: true, public_key: params.get("pbk") ?? "", short_id: params.get("sid") ?? "" };
  }
  return tls;
}

function transport(params: URLSearchParams): Record<string, unknown> | undefined {
  const type = params.get("type") ?? params.get("net") ?? "tcp";
  if (type === "ws") return { type: "ws", path: params.get("path") ?? "/", headers: params.get("host") ? { Host: params.get("host") } : undefined };
  if (type === "grpc") return { type: "grpc", service_name: params.get("serviceName") ?? params.get("serviceName") ?? "" };
  if (type === "http" || type === "h2") return { type: "http", path: params.get("path") ?? "/", host: params.get("host")?.split(",") };
  return undefined;
}

function parseVless(input: string): Record<string, unknown> {
  const uri = new URL(input);
  const params = uri.searchParams;
  return {
    type: "vless", tag: "proxy", server: uri.hostname, server_port: Number(uri.port || 443),
    uuid: decodeURIComponent(uri.username), flow: params.get("flow") || undefined,
    tls: baseTls(params, uri.hostname, true), transport: transport(params),
  };
}

function parseVmess(input: string): Record<string, unknown> {
  const encoded = input.slice("vmess://".length).trim();
  const json = JSON.parse(decodeBase64(encoded)) as Record<string, unknown>;
  const host = String(json.add ?? json.address ?? "");
  if (!host || !json.id) throw new Error("إعداد VMess ناقص العنوان أو UUID");
  const params = new URLSearchParams();
  params.set("type", String(json.net ?? "tcp"));
  if (json.host) params.set("host", String(json.host));
  if (json.path) params.set("path", String(json.path));
  if (json.sni) params.set("sni", String(json.sni));
  if (json.tls) params.set("security", "tls");
  return {
    type: "vmess", tag: "proxy", server: host, server_port: Number(json.port ?? 443), uuid: String(json.id),
    security: String(json.aid ?? "0") === "0" ? "auto" : "auto", alter_id: Number(json.aid ?? 0),
    tls: baseTls(params, host, Boolean(json.tls)), transport: transport(params),
  };
}

function parseTrojan(input: string): Record<string, unknown> {
  const uri = new URL(input);
  return {
    type: "trojan", tag: "proxy", server: uri.hostname, server_port: Number(uri.port || 443),
    password: decodeURIComponent(uri.username || uri.pathname.slice(1)), tls: baseTls(uri.searchParams, uri.hostname, true),
    transport: transport(uri.searchParams),
  };
}

function parseShadowsocks(input: string): Record<string, unknown> {
  const uri = new URL(input);
  const user = decodeBase64(uri.username);
  const separator = user.indexOf(":");
  if (separator < 1) throw new Error("رابط Shadowsocks غير صالح");
  return { type: "shadowsocks", tag: "proxy", server: uri.hostname, server_port: Number(uri.port), method: user.slice(0, separator), password: user.slice(separator + 1) };
}

function parseSocks(input: string): Record<string, unknown> {
  const uri = new URL(input);
  return { type: "socks", tag: "proxy", server: uri.hostname, server_port: Number(uri.port || 1080), version: "5", username: decodeURIComponent(uri.username), password: decodeURIComponent(uri.password) };
}

function parseHttp(input: string): Record<string, unknown> {
  const uri = new URL(input);
  return { type: "http", tag: "proxy", server: uri.hostname, server_port: Number(uri.port || (uri.protocol === "https:" ? 443 : 80)), username: decodeURIComponent(uri.username), password: decodeURIComponent(uri.password), tls: uri.protocol === "https:" ? { enabled: true, server_name: uri.hostname } : { enabled: false } };
}

function decodeBase64(value: string): string {
  const normalized = value.replace(/-/g, "+").replace(/_/g, "/").replace(/\s/g, "");
  const padded = normalized + "=".repeat((4 - (normalized.length % 4)) % 4);
  if (typeof globalThis.atob === "function") return decodeURIComponent(escape(globalThis.atob(padded)));
  // React Native Hermes exposes atob; this branch keeps web/Node type-checking deterministic.
  throw new Error("لا يمكن فك ترميز Base64 على هذا الجهاز");
}

export const singboxEvents = native ? new NativeEventEmitter(NativeModules.IbrahimSingbox) : null;
