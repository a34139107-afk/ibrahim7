import { Ionicons } from "@expo/vector-icons";
import { useState } from "react";
import { Linking, Pressable, ScrollView, StyleSheet, Switch, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { StatusBar } from "expo-status-bar";

const COLORS = {
  ink: "#071224",
  panel: "#0D1D33",
  border: "#1E3A58",
  text: "#F3FAFF",
  muted: "#8FA8BE",
  accent: "#2DE0BE",
  accentSoft: "#173D44",
};

function SettingRow({ icon, title, description, value, onValueChange }: { icon: keyof typeof Ionicons.glyphMap; title: string; description: string; value: boolean; onValueChange: (value: boolean) => void }) {
  return (
    <View style={styles.settingRow}>
      <Switch
        value={value}
        onValueChange={onValueChange}
        trackColor={{ false: "#263B53", true: "#287967" }}
        thumbColor={value ? COLORS.accent : "#8295A9"}
        accessibilityLabel={title}
      />
      <View style={styles.settingCopy}>
        <Text style={styles.settingTitle}>{title}</Text>
        <Text style={styles.settingDescription}>{description}</Text>
      </View>
      <View style={styles.settingIcon}>
        <Ionicons name={icon} size={19} color={COLORS.accent} />
      </View>
    </View>
  );
}

export default function SettingsScreen() {
  const [autoConnect, setAutoConnect] = useState(true);
  const [reconnect, setReconnect] = useState(true);
  const [notifications, setNotifications] = useState(false);

  return (
    <View style={styles.root}>
      <StatusBar style="light" />
      <SafeAreaView style={styles.safeArea} edges={["top", "left", "right"]}>
        <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
          <View style={styles.header}>
            <View>
              <Text style={styles.eyebrow}>تحكم كامل</Text>
              <Text style={styles.title}>الإعدادات</Text>
            </View>
            <View style={styles.headerMark}>
              <Ionicons name="options-outline" size={22} color={COLORS.accent} />
            </View>
          </View>

          <View style={styles.profileCard}>
            <View style={styles.profileMark}>
              <Ionicons name="shield-checkmark" size={25} color={COLORS.accent} />
            </View>
            <View style={styles.profileCopy}>
              <Text style={styles.profileName}>IBRAHIM VPN</Text>
              <Text style={styles.profileMeta}>الخطة الأساسية · حماية موثوقة</Text>
            </View>
            <View style={styles.activeBadge}><Text style={styles.activeBadgeText}>نشط</Text></View>
          </View>

          <Text style={styles.sectionTitle}>سلوك الاتصال</Text>
          <View style={styles.settingsCard}>
            <SettingRow
              icon="flash-outline"
              title="الاتصال التلقائي"
              description="اتصل تلقائيًا عند فتح التطبيق"
              value={autoConnect}
              onValueChange={setAutoConnect}
            />
            <View style={styles.rowDivider} />
            <SettingRow
              icon="refresh-outline"
              title="إعادة الاتصال"
              description="حاول استعادة الحماية عند انقطاع الشبكة"
              value={reconnect}
              onValueChange={setReconnect}
            />
          </View>

          <Text style={styles.sectionTitle}>التنبيهات</Text>
          <View style={styles.settingsCard}>
            <SettingRow
              icon="notifications-outline"
              title="تنبيهات حالة الاتصال"
              description="أخبرني عند بدء الجلسة أو توقفها"
              value={notifications}
              onValueChange={setNotifications}
            />
          </View>

          <Text style={styles.sectionTitle}>الجهاز والخصوصية</Text>
          <View style={styles.actionCard}>
            <Pressable style={({ pressed }) => [styles.actionRow, pressed && styles.pressed]}>
              <Ionicons name="chevron-back" size={17} color={COLORS.muted} />
              <View style={styles.actionCopy}>
                <Text style={styles.actionTitle}>إدارة ملف VPN</Text>
                <Text style={styles.actionDescription}>راجع أذونات الجهاز وإعداد الملف</Text>
              </View>
              <View style={[styles.actionIcon, { backgroundColor: "#173D44" }]}><Ionicons name="phone-portrait-outline" size={18} color={COLORS.accent} /></View>
            </Pressable>
            <View style={styles.rowDivider} />
            <Pressable style={({ pressed }) => [styles.actionRow, pressed && styles.pressed]}>
              <Ionicons name="chevron-back" size={17} color={COLORS.muted} />
              <View style={styles.actionCopy}>
                <Text style={styles.actionTitle}>سياسة الخصوصية</Text>
                <Text style={styles.actionDescription}>كيف نحافظ على بيانات اتصالك</Text>
              </View>
              <View style={[styles.actionIcon, { backgroundColor: "#26344B" }]}><Ionicons name="lock-closed-outline" size={18} color="#9EC4FF" /></View>
            </Pressable>
          </View>

          <Text style={styles.sectionTitle}>الدعم والتواصل</Text>
          <Pressable onPress={() => void Linking.openURL("https://t.me/a745x")} style={({ pressed }) => [styles.telegramCard, pressed && styles.pressed]} accessibilityRole="link" accessibilityLabel="تواصل مع المطور إبراهيم عبر Telegram">
            <View style={styles.telegramIcon}><Ionicons name="paper-plane-outline" size={22} color={COLORS.text} /></View>
            <View style={styles.telegramCopy}><Text style={styles.telegramTitle}>تواصل مع المطور إبراهيم</Text><Text style={styles.telegramDescription}>راسلني مباشرة عبر Telegram · @a745x</Text></View>
            <Ionicons name="chevron-back" size={17} color={COLORS.text} />
          </Pressable>

          <View style={styles.footerNote}>
            <Ionicons name="information-circle-outline" size={17} color={COLORS.muted} />
            <Text style={styles.footerText}>الإعدادات تُحفظ على جهازك وتظل تحت سيطرتك.</Text>
          </View>
          <Text style={styles.version}>IBRAHIM VPN · الإصدار 1.0.0</Text>
        </ScrollView>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: COLORS.ink },
  safeArea: { flex: 1, backgroundColor: COLORS.ink },
  content: { paddingHorizontal: 20, paddingTop: 14, paddingBottom: 34, gap: 17 },
  header: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between", marginBottom: 5 },
  eyebrow: { color: COLORS.accent, fontSize: 12, fontWeight: "700", textAlign: "right", marginBottom: 5 },
  title: { color: COLORS.text, fontSize: 29, fontWeight: "800", textAlign: "right" },
  headerMark: { width: 47, height: 47, borderRadius: 16, backgroundColor: COLORS.accentSoft, alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: "#276A70" },
  profileCard: { backgroundColor: COLORS.panel, borderRadius: 21, padding: 15, borderWidth: 1, borderColor: COLORS.border, flexDirection: "row-reverse", alignItems: "center", gap: 11 },
  profileMark: { width: 46, height: 46, borderRadius: 15, backgroundColor: COLORS.accentSoft, alignItems: "center", justifyContent: "center" },
  profileCopy: { flex: 1, alignItems: "flex-end", gap: 4 },
  profileName: { color: COLORS.text, fontSize: 14, fontWeight: "800" },
  profileMeta: { color: COLORS.muted, fontSize: 10 },
  activeBadge: { backgroundColor: COLORS.accentSoft, borderRadius: 8, paddingHorizontal: 8, paddingVertical: 5 },
  activeBadgeText: { color: COLORS.accent, fontSize: 10, fontWeight: "800" },
  sectionTitle: { color: COLORS.text, fontSize: 15, fontWeight: "800", textAlign: "right", marginTop: 4 },
  settingsCard: { backgroundColor: COLORS.panel, borderRadius: 19, borderWidth: 1, borderColor: COLORS.border, paddingHorizontal: 15 },
  settingRow: { minHeight: 76, flexDirection: "row", alignItems: "center", gap: 12 },
  settingCopy: { flex: 1, alignItems: "flex-end", gap: 5 },
  settingTitle: { color: COLORS.text, fontSize: 13, fontWeight: "700", textAlign: "right" },
  settingDescription: { color: COLORS.muted, fontSize: 10, textAlign: "right" },
  settingIcon: { width: 37, height: 37, borderRadius: 12, backgroundColor: COLORS.accentSoft, alignItems: "center", justifyContent: "center" },
  rowDivider: { height: 1, backgroundColor: COLORS.border },
  actionCard: { backgroundColor: COLORS.panel, borderRadius: 19, borderWidth: 1, borderColor: COLORS.border, paddingHorizontal: 15 },
  actionRow: { minHeight: 70, flexDirection: "row", alignItems: "center", gap: 11 },
  actionCopy: { flex: 1, alignItems: "flex-end", gap: 5 },
  actionTitle: { color: COLORS.text, fontSize: 13, fontWeight: "700", textAlign: "right" },
  actionDescription: { color: COLORS.muted, fontSize: 10, textAlign: "right" },
  actionIcon: { width: 37, height: 37, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  telegramCard: { minHeight: 74, borderRadius: 19, backgroundColor: "#168ACB", borderWidth: 1, borderColor: "#42A9DF", paddingHorizontal: 15, paddingVertical: 12, flexDirection: "row-reverse", alignItems: "center", gap: 11 },
  telegramIcon: { width: 43, height: 43, borderRadius: 15, backgroundColor: "rgba(255,255,255,0.17)", alignItems: "center", justifyContent: "center" },
  telegramCopy: { flex: 1, alignItems: "flex-end", gap: 4 },
  telegramTitle: { color: COLORS.text, fontSize: 13, fontWeight: "800", textAlign: "right" },
  telegramDescription: { color: "#D9F1FF", fontSize: 10, textAlign: "right" },
  pressed: { opacity: 0.7 },
  footerNote: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "center", gap: 7, paddingTop: 4 },
  footerText: { color: COLORS.muted, fontSize: 10 },
  version: { color: "#4E6880", fontSize: 10, textAlign: "center", marginTop: -7 },
});
