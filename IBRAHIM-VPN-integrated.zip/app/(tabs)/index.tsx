import { Ionicons } from "@expo/vector-icons";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { CameraView, useCameraPermissions } from "expo-camera";
import * as Clipboard from "expo-clipboard";
import * as FileSystem from "expo-file-system/legacy";
import * as Sharing from "expo-sharing";
import { useEffect, useMemo, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Linking,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  Share,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { StatusBar } from "expo-status-bar";

import { QrCode } from "@/components/qr-code";
import { proxyToSingboxConfig, singboxNative } from "@/lib/singbox-native";

const COLORS = {
  ink: "#071224",
  panel: "#0D1D33",
  raised: "#122844",
  border: "#1E3A58",
  text: "#F3FAFF",
  muted: "#8FA8BE",
  accent: "#2DE0BE",
  accentSoft: "#173D44",
  warning: "#F9C66B",
  danger: "#FF8B84",
};

type Protocol = "VLESS" | "VMess" | "Trojan" | "Shadowsocks" | "WireGuard" | "HTTP" | "SOCKS5";
type ProtocolChoice = Protocol | "تلقائي";
type ImportMode = "clipboard" | "manual";
type ExportMode = "code" | "config" | "qr";

const NATIVE_VPN_ENGINE_READY = singboxNative.available;

type Profile = {
  id: string;
  label: string;
  protocol: Protocol;
  code: string;
  source: "مستورد" | "يدوي";
  host: string;
  country: string;
  flag: string;
  pinned: boolean;
  status: "unknown" | "testing" | "active" | "dead";
  latencyMs?: number;
  speedMbps?: number;
};

const PROTOCOLS: { name: ProtocolChoice; icon: keyof typeof Ionicons.glyphMap; hint: string }[] = [
  { name: "تلقائي", icon: "sparkles-outline", hint: "ألصق الكود وسيتم التعرف تلقائيًا" },
  { name: "VLESS", icon: "flash-outline", hint: "vless://" },
  { name: "VMess", icon: "swap-horizontal-outline", hint: "vmess:// أو JSON" },
  { name: "Trojan", icon: "shield-outline", hint: "trojan://" },
  { name: "Shadowsocks", icon: "eye-outline", hint: "ss://" },
  { name: "WireGuard", icon: "key-outline", hint: "ملف أو نص WireGuard" },
  { name: "HTTP", icon: "browsers-outline", hint: "http:// أو https://" },
  { name: "SOCKS5", icon: "git-network-outline", hint: "socks5://" },
];

const SUPPORTED_PROTOCOLS: Protocol[] = ["VLESS", "VMess", "Trojan", "Shadowsocks", "WireGuard", "HTTP", "SOCKS5"];

function isProtocol(value: unknown): value is Protocol {
  return typeof value === "string" && SUPPORTED_PROTOCOLS.includes(value as Protocol);
}

function inferProtocol(input: string, fallback: Protocol | null): Protocol | null {
  const value = input.trim().toLowerCase();
  if (value.startsWith("vless://")) return "VLESS";
  if (value.startsWith("vmess://") || value.includes('"v":') || value.includes('"add":')) return "VMess";
  if (value.startsWith("trojan://")) return "Trojan";
  if (value.startsWith("ss://")) return "Shadowsocks";
  if (value.includes("[interface]") || value.includes("privatekey")) return "WireGuard";
  if (value.startsWith("socks5://") || value.startsWith("socks://")) return "SOCKS5";
  if (value.startsWith("http://") || value.startsWith("https://")) return "HTTP";
  return fallback;
}

function makeLabel(input: string, protocol: Protocol, index: number) {
  const hashIndex = input.indexOf("#");
  if (hashIndex >= 0 && input.slice(hashIndex + 1).trim()) {
    return decodeURIComponent(input.slice(hashIndex + 1).trim()).replace(/[-_]/g, " ");
  }
  try {
    const host = new URL(input).hostname;
    if (host) return `${protocol} · ${host}`;
  } catch {
    // JSON and WireGuard text do not have a URL host.
  }
  return `${protocol} · سيرفر ${index + 1}`;
}

function extractHost(input: string) {
  try {
    const parsed = new URL(input);
    if (parsed.hostname) return parsed.hostname;
  } catch {
    // JSON, .ovpn and WireGuard formats are handled by the expressions below.
  }
  const jsonMatch = input.match(/(?:"|')?(?:add|address|server|host|remote)(?:"|')?\s*[:=]\s*"?([a-zA-Z0-9.-]+)(?::(\d{2,5}))?/i);
  if (jsonMatch?.[1]) return jsonMatch[1];
  const remoteMatch = input.match(/(?:^|\s)remote\s+([a-zA-Z0-9.-]+)(?::(\d{2,5}))?/im);
  if (remoteMatch?.[1]) return remoteMatch[1];
  const atMatch = input.match(/@([a-zA-Z0-9.-]+)(?::\d{2,5})?/);
  return atMatch?.[1] ?? "";
}

function detectLocation(host: string, label: string) {
  const source = `${host} ${label}`.toLowerCase();
  const locations = [
    { tokens: [".jo", "jordan", "amman", "عمّان", "عمان"], country: "الأردن", flag: "🇯🇴" },
    { tokens: [".de", "germany", "frankfurt", "berlin", "munich"], country: "ألمانيا", flag: "🇩🇪" },
    { tokens: [".tr", "turkey", "istanbul", "تركيا"], country: "تركيا", flag: "🇹🇷" },
    { tokens: [".nl", "netherlands", "amsterdam", "هولندا"], country: "هولندا", flag: "🇳🇱" },
    { tokens: [".fr", "france", "paris", "فرنسا"], country: "فرنسا", flag: "🇫🇷" },
    { tokens: [".uk", "england", "london", "بريطانيا"], country: "بريطانيا", flag: "🇬🇧" },
    { tokens: [".us", "usa", "america", "newyork", "losangeles", "أمريكا"], country: "الولايات المتحدة", flag: "🇺🇸" },
    { tokens: [".ca", "canada", "toronto", "كندا"], country: "كندا", flag: "🇨🇦" },
    { tokens: [".jp", "japan", "tokyo", "اليابان"], country: "اليابان", flag: "🇯🇵" },
    { tokens: [".sg", "singapore", "سنغافورة"], country: "سنغافورة", flag: "🇸🇬" },
    { tokens: [".ae", "dubai", "uae", "الإمارات"], country: "الإمارات", flag: "🇦🇪" },
    { tokens: [".sa", "saudi", "riyadh", "السعودية"], country: "السعودية", flag: "🇸🇦" },
    { tokens: [".in", "india", "mumbai", "الهند"], country: "الهند", flag: "🇮🇳" },
    { tokens: [".au", "australia", "sydney", "أستراليا"], country: "أستراليا", flag: "🇦🇺" },
  ];
  const match = locations.find((location) => location.tokens.some((token) => source.includes(token)));
  return match ?? { country: "غير معروف", flag: "🌐" };
}

function flagFromCountryCode(code: string) {
  const normalized = code.trim().toUpperCase();
  if (normalized.length !== 2 || !/^[A-Z]{2}$/.test(normalized)) return "🌐";
  return String.fromCodePoint(...[...normalized].map((letter) => 127397 + letter.charCodeAt(0)));
}

async function resolveLocation(host: string, label: string) {
  const fallback = detectLocation(host, label);
  if (!host || fallback.country !== "غير معروف") return fallback;
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 4500);
  try {
    const response = await fetch(`https://ipwho.is/${encodeURIComponent(host)}?fields=success,country,country_code`, { signal: controller.signal });
    if (!response.ok) return fallback;
    const data = await response.json() as { success?: boolean; country?: string; country_code?: string };
    if (!data.success || !data.country) return fallback;
    return { country: data.country, flag: flagFromCountryCode(data.country_code ?? "") };
  } catch {
    return fallback;
  } finally {
    clearTimeout(timeout);
  }
}

function parseProfile(input: string, hint: Protocol | null, index: number): Profile | null {
  const clean = input.trim();
  const protocol = inferProtocol(clean, hint);
  if (!protocol) return null;
  let label = makeLabel(clean, protocol, index);
  try {
    const json = JSON.parse(clean) as { ps?: string; remarks?: string; name?: string; tag?: string };
    label = json.ps || json.remarks || json.name || json.tag || label;
  } catch {
    // URI and WireGuard formats remain unchanged.
  }
  const host = extractHost(clean);
  const location = detectLocation(host, label);
  return {
    id: `${Date.now()}-${index}`,
    label,
    protocol,
    code: clean,
    source: "مستورد",
    host,
    country: location.country,
    flag: location.flag,
    pinned: false,
    status: "unknown",
  };
}

function formatDuration(totalSeconds: number) {
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  return [hours, minutes, seconds].map((part) => String(part).padStart(2, "0")).join(":");
}

export default function HomeScreen() {
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [profilesReady, setProfilesReady] = useState(false);
  const [selectedProfile, setSelectedProfile] = useState<Profile | null>(null);
  const [selectedProtocol, setSelectedProtocol] = useState<ProtocolChoice>("تلقائي");
  const [connected, setConnected] = useState(false);
  const [connecting, setConnecting] = useState(false);
  const [connectionSeconds, setConnectionSeconds] = useState(0);
  const [showImport, setShowImport] = useState(false);
  const [showExport, setShowExport] = useState(false);
  const [showScanner, setShowScanner] = useState(false);
  const [importMode, setImportMode] = useState<ImportMode>("clipboard");
  const [exportMode, setExportMode] = useState<ExportMode>("code");
  const [manualCode, setManualCode] = useState("");
  const [notice, setNotice] = useState<string | null>(null);
  const [importing, setImporting] = useState(false);
  const [pingMs, setPingMs] = useState<number | null>(null);
  const [speedMbps, setSpeedMbps] = useState<number | null>(null);
  const [testingMetrics, setTestingMetrics] = useState(false);
  const [benchmarking, setBenchmarking] = useState(false);
  const [sortMode, setSortMode] = useState<"ping" | "speed" | "manual">("manual");
  const [editingProfile, setEditingProfile] = useState<Profile | null>(null);
  const [smartMode, setSmartMode] = useState(false);
  const [cameraPermission, requestCameraPermission] = useCameraPermissions();

  useEffect(() => {
    if (!connected) return;
    const timer = setInterval(() => setConnectionSeconds((value) => value + 1), 1000);
    return () => clearInterval(timer);
  }, [connected]);

  useEffect(() => {
    void AsyncStorage.getItem("ibrahim-vpn-profiles").then((value) => {
      if (!value) {
        setProfilesReady(true);
        return;
      }
      try {
        const saved = JSON.parse(value) as Profile[];
        const normalized = saved.filter((profile) => isProtocol(profile.protocol)).map((profile) => ({ ...profile, pinned: profile.pinned ?? false, status: profile.status === "dead" ? "unknown" as const : profile.status ?? "unknown" as const }));
        setProfiles(normalized);
        setSelectedProfile(normalized.find((profile) => profile.pinned) ?? normalized[0] ?? null);
      } catch {
        setProfiles([]);
      } finally {
        setProfilesReady(true);
      }
    });
  }, []);

  useEffect(() => {
    if (profilesReady) void AsyncStorage.setItem("ibrahim-vpn-profiles", JSON.stringify(profiles));
  }, [profiles, profilesReady]);

  useEffect(() => {
    if (!singboxNative.available) return;
    void singboxNative.status().then((running) => setConnected(running));
  }, []);

  useEffect(() => {
    if (!profilesReady) return;
    const unresolved = profiles.filter((profile) => profile.host && profile.country === "غير معروف");
    if (unresolved.length === 0) return;
    let cancelled = false;
    void Promise.all(unresolved.map(async (profile) => ({
      id: profile.id,
      location: await resolveLocation(profile.host, profile.label),
    }))).then((results) => {
      if (cancelled) return;
      setProfiles((items) => {
        let changed = false;
        const updated = items.map((profile) => {
        const result = results.find((item) => item.id === profile.id);
          if (!result || (result.location.country === profile.country && result.location.flag === profile.flag)) return profile;
          changed = true;
          return { ...profile, ...result.location };
        });
        return changed ? updated : items;
      });
    });
    return () => { cancelled = true; };
  }, [profilesReady, profiles]);

  const orderedProfiles = useMemo(() => [...profiles].sort((left, right) => {
    if (left.pinned !== right.pinned) return left.pinned ? -1 : 1;
    if (sortMode === "ping") return (left.latencyMs ?? Number.POSITIVE_INFINITY) - (right.latencyMs ?? Number.POSITIVE_INFINITY);
    if (sortMode === "speed") return (right.speedMbps ?? -1) - (left.speedMbps ?? -1);
    return 0;
  }), [profiles, sortMode]);

  const currentProtocol = useMemo(() => PROTOCOLS.find((item) => item.name === selectedProtocol) ?? { name: selectedProtocol, icon: "code-slash-outline" as keyof typeof Ionicons.glyphMap, hint: "أدخل إعداد أحد البروتوكولات المدعومة" }, [selectedProtocol]);
  const activeProtocol = selectedProfile?.protocol ?? selectedProtocol;
  const activeLabel = selectedProfile?.label ?? "لا يوجد سيرفر محفوظ";

  const showNotice = (message: string) => {
    setNotice(message);
    setTimeout(() => setNotice(null), 2600);
  };

  const measureConnection = async () => {
    setTestingMetrics(true);
    setPingMs(null);
    setSpeedMbps(null);
    const started = performance.now();
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 9000);
    try {
      const response = await fetch("https://speed.cloudflare.com/__down?bytes=500000", {
        cache: "no-store",
        signal: controller.signal,
      });
      const body = await response.arrayBuffer();
      const elapsed = Math.max((performance.now() - started) / 1000, 0.05);
      setPingMs(Math.max(1, Math.round(performance.now() - started)));
      setSpeedMbps(Number(((body.byteLength * 8) / elapsed / 1_000_000).toFixed(1)));
    } catch {
      showNotice("تعذر قياس السرعة الآن، حاول إعادة الفحص");
    } finally {
      clearTimeout(timeout);
      setTestingMetrics(false);
    }
  };

  const chooseFastestServer = async (): Promise<Profile | null> => {
    if (profiles.length === 0) {
      showNotice("أضف سيرفرًا واحدًا على الأقل لفحص السرعة");
      return null;
    }
    setBenchmarking(true);
    const results = await Promise.all(profiles.map(async (profile) => {
      if (!profile.host) return { profile, latency: Number.POSITIVE_INFINITY };
      const started = performance.now();
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 3500);
      try {
        await fetch(`https://${profile.host}`, { method: "HEAD", cache: "no-store", signal: controller.signal });
        return { profile, latency: Math.round(performance.now() - started) };
      } catch {
        return { profile, latency: Number.POSITIVE_INFINITY };
      } finally {
        clearTimeout(timeout);
      }
    }));
    const fastest = results.sort((left, right) => left.latency - right.latency)[0];
    setBenchmarking(false);
    if (!fastest || !Number.isFinite(fastest.latency)) {
      showNotice("تعذر قياس عناوين السيرفرات، اختر سيرفرًا يدويًا");
      return null;
    }
    setSelectedProfile(fastest.profile);
    setSelectedProtocol(fastest.profile.protocol);
    showNotice(`تم اختيار ${fastest.profile.label} · ${fastest.latency} ms`);
    return fastest.profile;
  };

  useEffect(() => {
    if (!connected || !smartMode || profiles.length < 2) return;
    const timer = setInterval(() => {
      void chooseFastestServer();
    }, 30000);
    return () => clearInterval(timer);
  // The benchmark callback is intentionally recreated with the current profile list.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [connected, smartMode, profiles.length]);

  const probeProfile = async (profile: Profile) => {
    if (!profile.host) return { status: "unknown" as const, latencyMs: undefined, speedMbps: undefined };
    const started = performance.now();
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 5000);
    try {
      const response = await fetch(`https://${profile.host}`, { cache: "no-store", signal: controller.signal });
      const body = await response.arrayBuffer();
      const elapsed = Math.max((performance.now() - started) / 1000, 0.05);
      return { status: response.ok ? "active" as const : "unknown" as const, latencyMs: Math.round(performance.now() - started), speedMbps: Number(((body.byteLength * 8) / elapsed / 1_000_000).toFixed(1)) };
    } catch {
      // HTTPS cannot validate VLESS, VMess, Trojan, WireGuard, and other VPN protocols.
      return { status: "unknown" as const, latencyMs: undefined, speedMbps: undefined };
    } finally {
      clearTimeout(timeout);
    }
  };

  const checkAllProfiles = async () => {
    if (profiles.length === 0) {
      showNotice("لا توجد سيرفرات للفحص");
      return;
    }
    setBenchmarking(true);
    setProfiles((items) => items.map((profile) => ({ ...profile, status: "testing" })));
    const results = await Promise.all(profiles.map(async (profile) => ({ id: profile.id, result: await probeProfile(profile) })));
    setProfiles((items) => items.map((profile) => {
      const match = results.find((item) => item.id === profile.id);
      return match ? { ...profile, ...match.result } : profile;
    }));
    setBenchmarking(false);
    showNotice("اكتمل الفحص؛ السيرفر غير HTTP يظهر كغير معروف وليس ميتًا");
  };

  const shareProfile = async (profile: Profile) => {
    await Share.share({ message: profile.code, title: `${profile.label} · ${profile.protocol}` });
  };

  const deleteProfile = (profile: Profile) => {
    Alert.alert("حذف السيرفر", `هل تريد حذف ${profile.label}؟`, [
      { text: "إلغاء", style: "cancel" },
      { text: "حذف", style: "destructive", onPress: () => { setProfiles((items) => items.filter((item) => item.id !== profile.id)); if (selectedProfile?.id === profile.id) setSelectedProfile(null); showNotice("تم حذف السيرفر"); } },
    ]);
  };

  const deleteAllProfiles = () => {
    if (profiles.length === 0) return;
    Alert.alert("حذف جميع السيرفرات", "سيتم حذف كل الإعدادات المحفوظة من الجهاز.", [
      { text: "إلغاء", style: "cancel" },
      { text: "حذف الكل", style: "destructive", onPress: () => { setProfiles([]); setSelectedProfile(null); showNotice("تم حذف جميع السيرفرات"); } },
    ]);
  };

  const deleteDeadProfiles = () => {
    const deadIds = new Set(profiles.filter((profile) => profile.status === "dead").map((profile) => profile.id));
    if (deadIds.size === 0) {
      showNotice("لا توجد سيرفرات ميتة محكومة بالفحص");
      return;
    }
    setProfiles((items) => items.filter((profile) => !deadIds.has(profile.id)));
    if (selectedProfile && deadIds.has(selectedProfile.id)) setSelectedProfile(null);
    showNotice(`تم حذف ${deadIds.size} سيرفر ميت`);
  };

  const togglePin = (profile: Profile) => {
    setProfiles((items) => items.map((item) => item.id === profile.id ? { ...item, pinned: !item.pinned } : item));
    showNotice(profile.pinned ? "تم إلغاء تثبيت السيرفر" : "تم تثبيت السيرفر في الأعلى");
  };

  const startEdit = (profile: Profile) => {
    setEditingProfile(profile);
    setManualCode(profile.code);
    setSelectedProtocol(profile.protocol);
    setImportMode("manual");
    setShowImport(true);
  };

  const openScanner = async () => {
    if (!cameraPermission?.granted) {
      const result = await requestCameraPermission();
      if (!result.granted) {
        showNotice("اسمح للكاميرا حتى تتمكن من مسح الباركود");
        return;
      }
    }
    setShowScanner(true);
  };

  const importScannedCode = async (data: string) => {
    const clean = data.trim();
    if (!clean) return;
    const parsed = parseProfile(clean, selectedProtocol === "تلقائي" ? null : selectedProtocol, profiles.length);
    if (!parsed) {
      showNotice("البروتوكول غير مدعوم. استخدم VLESS أو VMess أو Trojan أو Shadowsocks أو WireGuard أو HTTP أو SOCKS5.");
      return;
    }
    const imported = { ...parsed, ...(await resolveLocation(parsed.host, parsed.label)) };
    setProfiles((items) => [imported, ...items]);
    setSelectedProfile(imported);
    setSelectedProtocol(imported.protocol);
    setShowScanner(false);
    showNotice(`تم استيراد ${imported.protocol} من الباركود`);
  };

  const handleConnection = async () => {
    if (connected) {
      await singboxNative.disconnect();
      setConnected(false);
      setConnectionSeconds(0);
      setPingMs(null);
      setSpeedMbps(null);
      showNotice("تم قطع الاتصال");
      return;
    }
    if (!NATIVE_VPN_ENGINE_READY) {
      showNotice("هذه نسخة Web/Expo Go؛ ابنِ نسخة Android Native لتشغيل VPN الحقيقي");
      return;
    }
    const profile = smartMode && profiles.length > 1 ? await chooseFastestServer() : selectedProfile;
    if (!profile) {
      showNotice("أضف كود السيرفر من الحافظة أو الإدخال اليدوي أولًا");
      return;
    }
    setConnecting(true);
    try {
      const config = proxyToSingboxConfig(profile.code);
      const result = await singboxNative.connect(config);
      if (result === "permission_required") {
        showNotice("اسمح للتطبيق بإنشاء اتصال VPN ثم اضغط اتصال مرة أخرى");
        return;
      }
      let running = false;
      for (let attempt = 0; attempt < 20; attempt += 1) {
        running = await singboxNative.status();
        if (running) break;
        await new Promise((resolve) => setTimeout(resolve, 250));
      }
      if (!running) throw new Error("لم تؤكد خدمة VPN نجاح التشغيل");
      setConnected(true);
      void measureConnection();
      showNotice(`تم الاتصال عبر ${profile.protocol}`);
    } catch (error) {
      setConnected(false);
      showNotice(error instanceof Error ? error.message : "فشل تشغيل نفق VPN؛ تحقق من الإعداد وإذن VPN");
    } finally {
      setConnecting(false);
    }
  };

  const importFromClipboard = async () => {
    setImporting(true);
    try {
      const value = await Clipboard.getStringAsync();
      if (!value.trim()) {
        showNotice("الحافظة فارغة. انسخ كود السيرفر أولًا.");
        return;
      }
      const parsed = parseProfile(value, selectedProtocol === "تلقائي" ? null : selectedProtocol, profiles.length);
      if (!parsed) {
        showNotice("الكود ليس من البروتوكولات المدعومة: VLESS أو VMess أو Trojan أو Shadowsocks أو WireGuard أو HTTP أو SOCKS5.");
        return;
      }
      const imported = { ...parsed, ...(await resolveLocation(parsed.host, parsed.label)) };
      setProfiles((items) => [imported, ...items]);
      setSelectedProfile(imported);
      setSelectedProtocol(imported.protocol);
      setShowImport(false);
      showNotice(`تم استيراد ${imported.protocol} من الحافظة`);
    } catch {
      showNotice("تعذر قراءة الحافظة على هذا الجهاز");
    } finally {
      setImporting(false);
    }
  };

  const saveManualProfile = async () => {
    if (!manualCode.trim()) {
      showNotice(`أدخل كود ${selectedProtocol} أو ألصقه في الحقل`);
      return;
    }
    const parsed = parseProfile(manualCode, selectedProtocol === "تلقائي" ? null : selectedProtocol, profiles.length);
    if (!parsed) {
      showNotice("اختر بروتوكولًا مدعومًا أو أدخل كودًا معروفًا حتى يتم التعرف عليه تلقائيًا.");
      return;
    }
    const imported = { ...parsed, ...(await resolveLocation(parsed.host, parsed.label)), source: "يدوي" as const, pinned: editingProfile?.pinned ?? false };
    if (editingProfile) {
      const updated = { ...imported, id: editingProfile.id };
      setProfiles((items) => items.map((item) => item.id === editingProfile.id ? updated : item));
      setSelectedProfile(updated);
      setEditingProfile(null);
      showNotice("تم تعديل كود السيرفر وحفظه");
    } else {
      setProfiles((items) => [imported, ...items]);
      setSelectedProfile(imported);
      showNotice("تم حفظ السيرفر داخل التطبيق");
    }
    setShowImport(false);
    setManualCode("");
  };

  const copyCode = async () => {
    if (!selectedProfile) return;
    await Clipboard.setStringAsync(selectedProfile.code);
    showNotice("تم نسخ كود السيرفر");
  };

  const getConfigFilename = (protocol: Protocol) => {
    const extension = protocol === "WireGuard" ? "conf" : protocol === "VMess" ? "json" : "txt";
    return `${protocol.toLowerCase()}-server.${extension}`;
  };

  const downloadOnWeb = () => {
    if (Platform.OS !== "web" || !selectedProfile) return false;
    const blob = new Blob([selectedProfile.code], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = getConfigFilename(selectedProfile.protocol);
    anchor.click();
    URL.revokeObjectURL(url);
    return true;
  };

  const exportFile = async () => {
    if (!selectedProfile) return;
    if (downloadOnWeb()) {
      showNotice("تم تنزيل ملف السيرفر");
      return;
    }
    try {
      const uri = `${FileSystem.cacheDirectory}${getConfigFilename(selectedProfile.protocol)}`;
      await FileSystem.writeAsStringAsync(uri, selectedProfile.code, { encoding: FileSystem.EncodingType.UTF8 });
      if (await Sharing.isAvailableAsync()) {
        await Sharing.shareAsync(uri, { mimeType: "text/plain", dialogTitle: "تصدير إعداد VPN" });
      } else {
        showNotice("تم تجهيز ملف السيرفر داخل التطبيق");
      }
    } catch {
      showNotice("تعذر إنشاء الملف على هذا الجهاز");
    }
  };

  const exportSelected = () => {
    if (!selectedProfile) return;
    if (exportMode === "code") void copyCode();
    if (exportMode === "config") void exportFile();
    if (exportMode === "qr") showNotice("اعرض QR ثم امسحه من جهاز آخر");
  };

  return (
    <View style={styles.root}>
      <StatusBar style="light" />
      <SafeAreaView style={styles.safeArea} edges={["top", "left", "right"]}>
        <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
          <View style={styles.header}>
            <View style={styles.brandBlock}>
              <View style={styles.brandMark}><Ionicons name="shield-checkmark" size={22} color={COLORS.accent} /></View>
              <View><Text style={styles.brandName}>IBRAHIM VPN</Text><Text style={styles.brandCaption}>مدير السيرفرات والبروتوكولات</Text></View>
            </View>
            <View style={styles.protocolCount}><Text style={styles.protocolCountNumber}>{SUPPORTED_PROTOCOLS.length}</Text><Text style={styles.protocolCountLabel}>بروتوكولات</Text></View>
          </View>

          <View style={styles.heroRow}>
            <View style={styles.heroCopy}>
              <Text style={styles.eyebrow}>اتصالك تحت سيطرتك</Text>
              <Text style={styles.title}>مع إبراهيم اتصالك آمن</Text>
              <Text style={styles.subtitle}>أضف سيرفرًا بأحد البروتوكولات السبعة المدعومة.</Text>
              <Pressable onPress={() => void Linking.openURL("https://t.me/a745x")} style={({ pressed }) => [styles.contactLink, pressed && styles.pressed]} accessibilityRole="link" accessibilityLabel="تواصل مع المطور إبراهيم عبر Telegram"><View style={styles.contactTelegramIcon}><Ionicons name="paper-plane" size={18} color="#FFFFFF" /></View><View style={styles.contactCopy}><Text style={styles.contactLinkText}>تواصل مع المطور إبراهيم</Text><Text style={styles.contactUsername}>Telegram · @a745x</Text></View><Ionicons name="chevron-back" size={16} color="#BDEBFF" /></Pressable>
            </View>
            <View style={styles.heroBadge}><Ionicons name="link-outline" size={24} color={COLORS.accent} /></View>
          </View>

          <View style={styles.turboCard}><View style={styles.turboIcon}><Ionicons name="speedometer-outline" size={22} color={COLORS.accent} /></View><View style={styles.turboCopy}><Text style={styles.turboTitle}>وضع الأداء الأقصى</Text><Text style={styles.turboDescription}>يفحص السيرفرات المحفوظة بالتوازي ويختار الأقل استجابة.</Text></View><Pressable accessibilityLabel="اختيار أسرع سيرفر" disabled={benchmarking} onPress={() => void chooseFastestServer()} style={({ pressed }) => [styles.turboButton, pressed && styles.pressed]}>{benchmarking ? <ActivityIndicator size="small" color={COLORS.ink} /> : <><Ionicons name="flash" size={16} color={COLORS.ink} /><Text style={styles.turboButtonText}>فحص</Text></>}</Pressable></View>

          <View style={[styles.connectionCard, connected && styles.connectionCardActive]}>
            <View style={styles.cardTopline}>
              <View style={[styles.statusIcon, connected && styles.statusIconActive]}><Ionicons name={connected ? "lock-closed" : "shield-outline"} size={27} color={connected ? COLORS.accent : COLORS.muted} /></View>
              <View style={styles.statusCopyBlock}><Text style={styles.cardEyebrow}>{connected ? "الحماية مفعّلة" : "السيرفر المحدد"}</Text><Text style={styles.cardTitle}>{connected ? "أنت متصل بأمان" : activeLabel}</Text></View>
              <View style={[styles.protocolBadge, connected && styles.protocolBadgeActive]}><Text style={[styles.protocolBadgeText, connected && styles.protocolBadgeTextActive]}>{activeProtocol}</Text></View>
            </View>
            <View style={styles.connectionLine} />
            <Text style={styles.cardDescription}>{connected ? `الجلسة تعمل عبر ${activeProtocol} · ${formatDuration(connectionSeconds)}` : selectedProfile ? "جاهز لتشغيل نفق VPN حقيقي عبر محرك sing-box الأصلي." : "لا يوجد سيرفر بعد. أضف كودًا بأحد البروتوكولات المدعومة من الأسفل."}</Text>
            {selectedProfile && <View style={styles.serverMetaRow}><Text style={styles.serverFlag}>{selectedProfile.flag}</Text><View style={styles.serverMetaCopy}><Text style={styles.serverMetaName}>{selectedProfile.label}</Text><Text style={styles.serverMetaHost}>{selectedProfile.country} · {selectedProfile.host || "العنوان من الكود"}</Text></View><Ionicons name="location-outline" size={17} color={COLORS.accent} /></View>}
            <Pressable onPress={handleConnection} style={({ pressed }) => [styles.connectButton, connected && styles.disconnectButton, pressed && styles.pressed]}>
              {connecting ? <ActivityIndicator color={COLORS.ink} /> : <><Ionicons name={connected ? "close" : "power"} size={20} color={connected ? COLORS.text : COLORS.ink} /><Text style={[styles.connectButtonText, connected && styles.disconnectButtonText]}>{connected ? "قطع الاتصال" : NATIVE_VPN_ENGINE_READY ? "اتصال بالسيرفر" : "المحرك غير جاهز"}</Text></>}
            </Pressable>
            {connected && <><View style={styles.connectionStats}><View style={styles.statItem}><Text style={styles.statValue}>{testingMetrics ? "..." : pingMs ? `${pingMs} ms` : "—"}</Text><Text style={styles.statLabel}>البنج</Text></View><View style={styles.statDivider} /><View style={styles.statItem}><Text style={styles.statValue}>{testingMetrics ? "..." : speedMbps ? `${speedMbps} Mbps` : "—"}</Text><Text style={styles.statLabel}>سرعة النت</Text></View><View style={styles.statDivider} /><View style={styles.statItem}><Text style={styles.statValue}>{formatDuration(connectionSeconds)}</Text><Text style={styles.statLabel}>المدة</Text></View><View style={styles.statDivider} /><View style={styles.statItem}><Text style={styles.statValue}>{activeProtocol}</Text><Text style={styles.statLabel}>البروتوكول</Text></View></View><Pressable onPress={() => void measureConnection()} style={styles.testAgain}><Ionicons name="speedometer-outline" size={14} color={COLORS.accent} /><Text style={styles.testAgainText}>{testingMetrics ? "جارٍ فحص البنج والسرعة..." : "إعادة فحص البنج والسرعة"}</Text></Pressable></>}
          </View>

          {notice && <View style={styles.notice}><Ionicons name="checkmark-circle" size={19} color={COLORS.accent} /><Text style={styles.noticeText}>{notice}</Text></View>}

            <View style={styles.sectionHeader}><View><Text style={styles.sectionTitle}>بروتوكول السيرفر</Text><Text style={styles.sectionHint}>اختر واحدًا من البروتوكولات السبعة أو اتركه تلقائيًا</Text></View><View style={styles.autoTag}><Ionicons name="sparkles-outline" size={13} color={COLORS.warning} /><Text style={styles.autoTagText}>متعدد</Text></View></View>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.protocolList} directionalLockEnabled>
            {PROTOCOLS.map((protocol) => <Pressable key={protocol.name} onPress={() => setSelectedProtocol(protocol.name)} style={({ pressed }) => [styles.protocolChip, selectedProtocol === protocol.name && styles.protocolChipActive, pressed && styles.pressed]}><Ionicons name={protocol.icon} size={16} color={selectedProtocol === protocol.name ? COLORS.ink : COLORS.muted} /><Text style={[styles.protocolChipText, selectedProtocol === protocol.name && styles.protocolChipTextActive]}>{protocol.name}</Text></Pressable>)}
          </ScrollView>

          <View style={styles.importGrid}>
            <Pressable onPress={() => { setImportMode("clipboard"); setShowImport(true); }} style={({ pressed }) => [styles.importCard, pressed && styles.pressed]}><View style={[styles.importIcon, { backgroundColor: COLORS.accentSoft }]}><Ionicons name="clipboard-outline" size={21} color={COLORS.accent} /></View><Text style={styles.importTitle}>من الحافظة</Text><Text style={styles.importHint}>الصق الكود</Text></Pressable>
            <Pressable onPress={() => void openScanner()} style={({ pressed }) => [styles.importCard, pressed && styles.pressed]}><View style={[styles.importIcon, { backgroundColor: "#26344B" }]}><Ionicons name="qr-code-outline" size={21} color="#9EC4FF" /></View><Text style={styles.importTitle}>مسح باركود</Text><Text style={styles.importHint}>افتح الكاميرا</Text></Pressable>
            <Pressable onPress={() => { setImportMode("manual"); setEditingProfile(null); setShowImport(true); }} style={({ pressed }) => [styles.importCard, pressed && styles.pressed]}><View style={[styles.importIcon, { backgroundColor: "#26344B" }]}><Ionicons name="create-outline" size={21} color="#9EC4FF" /></View><Text style={styles.importTitle}>إدخال يدوي</Text><Text style={styles.importHint}>كود أو ملف</Text></Pressable>
          </View>

          <View style={styles.sectionHeader}><View><Text style={styles.sectionTitle}>مدير السيرفرات</Text><Text style={styles.sectionHint}>{profiles.length} سيرفر محفوظ داخل جهازك</Text></View><Pressable onPress={() => void checkAllProfiles()} disabled={benchmarking}><Text style={styles.textAction}>{benchmarking ? "جارٍ الفحص..." : "فحص الكل"}</Text></Pressable></View>
          {profiles.length > 0 ? <>
            <View style={styles.managerToolbar}><Pressable onPress={() => setSortMode("ping")} style={[styles.sortChip, sortMode === "ping" && styles.sortChipActive]}><Ionicons name="speedometer-outline" size={14} color={sortMode === "ping" ? COLORS.ink : COLORS.muted} /><Text style={[styles.sortChipText, sortMode === "ping" && styles.sortChipTextActive]}>أقل بنج</Text></Pressable><Pressable onPress={() => setSortMode("speed")} style={[styles.sortChip, sortMode === "speed" && styles.sortChipActive]}><Ionicons name="flash-outline" size={14} color={sortMode === "speed" ? COLORS.ink : COLORS.muted} /><Text style={[styles.sortChipText, sortMode === "speed" && styles.sortChipTextActive]}>أسرع</Text></Pressable><Pressable onPress={() => setSmartMode((value) => !value)} style={[styles.sortChip, smartMode && styles.sortChipActive]}><Ionicons name="sparkles-outline" size={14} color={smartMode ? COLORS.ink : COLORS.muted} /><Text style={[styles.sortChipText, smartMode && styles.sortChipTextActive]}>اتصال ذكي</Text></Pressable></View>
            <View style={styles.bulkActions}><Pressable onPress={deleteDeadProfiles} style={styles.bulkAction}><Ionicons name="trash-outline" size={15} color={COLORS.danger} /><Text style={styles.bulkActionDanger}>حذف المؤكد ميت</Text></Pressable><Pressable onPress={deleteAllProfiles} style={styles.bulkAction}><Ionicons name="trash-bin-outline" size={15} color={COLORS.danger} /><Text style={styles.bulkActionDanger}>حذف الكل</Text></Pressable></View>
            <View style={styles.serverList}>{orderedProfiles.map((profile) => <View key={profile.id} style={[styles.serverItem, selectedProfile?.id === profile.id && styles.serverItemSelected]}><Pressable onPress={() => { setSelectedProfile(profile); setSelectedProtocol(profile.protocol); }} style={styles.serverMain}><View style={styles.serverStatusDot}><Text style={styles.serverFlagSmall}>{profile.flag}</Text></View><View style={styles.serverListCopy}><Text style={styles.serverListName}>{profile.pinned ? "★ " : ""}{profile.label}</Text><Text style={styles.serverListMeta}>{profile.protocol} · {profile.country} · {profile.host || "عنوان غير مستخرج"}</Text></View><View style={styles.serverMetrics}><Text style={[styles.serverState, profile.status === "active" && styles.serverStateActive, profile.status === "dead" && styles.serverStateDead]}>{profile.status === "active" ? "نشط" : profile.status === "dead" ? "ميت" : profile.status === "testing" ? "يفحص" : "غير مفحوص"}</Text><Text style={styles.serverMetricText}>{profile.latencyMs ? `${profile.latencyMs} ms` : "—"} · {profile.speedMbps ? `${profile.speedMbps} Mbps` : "—"}</Text></View></Pressable><View style={styles.serverActions}><Pressable onPress={() => togglePin(profile)} style={styles.serverAction}><Ionicons name={profile.pinned ? "star" : "star-outline"} size={16} color={profile.pinned ? COLORS.warning : COLORS.muted} /></Pressable><Pressable onPress={() => startEdit(profile)} style={styles.serverAction}><Ionicons name="create-outline" size={16} color={COLORS.muted} /></Pressable><Pressable onPress={() => void shareProfile(profile)} style={styles.serverAction}><Ionicons name="share-social-outline" size={16} color={COLORS.muted} /></Pressable><Pressable onPress={() => { setSelectedProfile(profile); setShowExport(true); }} style={styles.serverAction}><Ionicons name="download-outline" size={16} color={COLORS.accent} /></Pressable><Pressable onPress={() => deleteProfile(profile)} style={styles.serverAction}><Ionicons name="trash-outline" size={16} color={COLORS.danger} /></Pressable></View></View>)}</View>
          </> : <View style={styles.emptyCard}><View style={styles.emptyIcon}><Ionicons name="server-outline" size={26} color={COLORS.accent} /></View><Text style={styles.emptyTitle}>ما عندك سيرفرات محفوظة بعد</Text><Text style={styles.emptyBody}>الصق كود من الحافظة أو أدخله يدويًا، وسيظهر هنا مع البنج والسرعة والحالة.</Text><Pressable onPress={() => { setImportMode("clipboard"); setShowImport(true); }} style={({ pressed }) => [styles.emptyButton, pressed && styles.pressed]}><Ionicons name="clipboard-outline" size={17} color={COLORS.ink} /><Text style={styles.emptyButtonText}>إضافة أول سيرفر</Text></Pressable></View>}

          <View style={styles.tipCard}><Ionicons name="information-circle-outline" size={18} color={COLORS.warning} /><Text style={styles.tipText}>البروتوكولات المتاحة: VLESS وVMess وTrojan وShadowsocks وWireGuard وHTTP وSOCKS5. تُحفظ إعداداتك داخل جهازك.</Text></View>
        </ScrollView>
      </SafeAreaView>

      <Modal visible={showScanner} transparent animationType="slide" onRequestClose={() => setShowScanner(false)}>
        <View style={styles.scannerBackdrop}><View style={styles.scannerSheet}><View style={styles.modalHandle} /><View style={styles.modalHeader}><View><Text style={styles.modalEyebrow}>استيراد مباشر</Text><Text style={styles.modalTitle}>مسح باركود السيرفر</Text></View><Pressable onPress={() => setShowScanner(false)} style={styles.closeButton}><Ionicons name="close" size={20} color={COLORS.muted} /></Pressable></View><Text style={styles.scannerHint}>وجّه الكاميرا إلى QR الخاص بأحد البروتوكولات المدعومة.</Text>{cameraPermission?.granted ? <View style={styles.cameraFrame}><CameraView style={styles.cameraView} facing="back" barcodeScannerSettings={{ barcodeTypes: ["qr"] }} onBarcodeScanned={({ data }) => importScannedCode(data)} /><View style={styles.scanCorners} /></View> : <View style={styles.cameraPermission}><Ionicons name="camera-outline" size={34} color={COLORS.accent} /><Text style={styles.panelBody}>نحتاج إذن الكاميرا حتى نقرأ الباركود.</Text><Pressable onPress={() => void openScanner()} style={styles.modalButton}><Text style={styles.modalButtonText}>السماح بالكاميرا</Text></Pressable></View>}</View></View>
      </Modal>

      <Modal visible={showImport} transparent animationType="slide" onRequestClose={() => setShowImport(false)}>
        <View style={styles.modalBackdrop}><View style={styles.modalSheet}><View style={styles.modalHandle} /><View style={styles.modalHeader}><View><Text style={styles.modalEyebrow}>{importMode === "clipboard" ? "استيراد سريع" : "إضافة سيرفر"}</Text><Text style={styles.modalTitle}>{importMode === "clipboard" ? "من الحافظة" : `إدخال ${selectedProtocol}`}</Text></View><Pressable onPress={() => setShowImport(false)} style={styles.closeButton}><Ionicons name="close" size={20} color={COLORS.muted} /></Pressable></View>
          <View style={styles.modeTabs}><Pressable onPress={() => setImportMode("clipboard")} style={[styles.modeTab, importMode === "clipboard" && styles.modeTabActive]}><Text style={[styles.modeTabText, importMode === "clipboard" && styles.modeTabTextActive]}>من الحافظة</Text></Pressable><Pressable onPress={() => setImportMode("manual")} style={[styles.modeTab, importMode === "manual" && styles.modeTabActive]}><Text style={[styles.modeTabText, importMode === "manual" && styles.modeTabTextActive]}>إدخال يدوي</Text></Pressable></View>
          {importMode === "clipboard" ? <View style={styles.clipboardPanel}><View style={styles.bigImportIcon}><Ionicons name="clipboard-outline" size={28} color={COLORS.accent} /></View><Text style={styles.panelTitle}>الصق الكود من أي تطبيق</Text><Text style={styles.panelBody}>سيتعرف IBRAHIM VPN تلقائيًا على البروتوكول من بداية الكود، مثل vless:// أو vmess:// أو ss://.</Text><Pressable onPress={() => void importFromClipboard()} style={({ pressed }) => [styles.modalButton, pressed && styles.pressed]}>{importing ? <ActivityIndicator color={COLORS.ink} /> : <><Ionicons name="clipboard" size={18} color={COLORS.ink} /><Text style={styles.modalButtonText}>قراءة الحافظة واستيراد</Text></>}</Pressable></View> : <View><Text style={styles.inputLabel}>كود السيرفر أو محتوى ملف الإعداد</Text><TextInput value={manualCode} onChangeText={setManualCode} multiline numberOfLines={6} placeholder={currentProtocol.hint} placeholderTextColor="#58718A" style={styles.codeInput} autoCapitalize="none" autoCorrect={false} textAlign="right" /><Text style={styles.inputHint}>سيُحفظ النص كما هو داخل التطبيق ويمكنك تصديره لاحقًا.</Text><Pressable onPress={saveManualProfile} style={({ pressed }) => [styles.modalButton, pressed && styles.pressed]}><Ionicons name="save-outline" size={18} color={COLORS.ink} /><Text style={styles.modalButtonText}>حفظ السيرفر داخليًا</Text></Pressable></View>}
        </View></View>
      </Modal>

      {selectedProfile && <Modal visible={showExport} transparent animationType="slide" onRequestClose={() => setShowExport(false)}>
        <View style={styles.modalBackdrop}><View style={styles.modalSheet}><View style={styles.modalHandle} /><View style={styles.modalHeader}><View><Text style={styles.modalEyebrow}>سيرفر داخلي</Text><Text style={styles.modalTitle}>تصدير الإعداد</Text></View><Pressable onPress={() => setShowExport(false)} style={styles.closeButton}><Ionicons name="close" size={20} color={COLORS.muted} /></Pressable></View><Text style={styles.exportName}>{selectedProfile.label} · {selectedProfile.protocol}</Text>
          <View style={styles.modeTabs}><Pressable onPress={() => setExportMode("code")} style={[styles.modeTab, exportMode === "code" && styles.modeTabActive]}><Text style={[styles.modeTabText, exportMode === "code" && styles.modeTabTextActive]}>كود</Text></Pressable><Pressable onPress={() => setExportMode("config")} style={[styles.modeTab, exportMode === "config" && styles.modeTabActive]}><Text style={[styles.modeTabText, exportMode === "config" && styles.modeTabTextActive]}>كونفج</Text></Pressable><Pressable onPress={() => setExportMode("qr")} style={[styles.modeTab, exportMode === "qr" && styles.modeTabActive]}><Text style={[styles.modeTabText, exportMode === "qr" && styles.modeTabTextActive]}>باركود</Text></Pressable></View>
          {exportMode === "code" && <View><Text style={styles.inputLabel}>الكود القابل للنسخ</Text><View style={styles.codePreview}><Text selectable style={styles.codePreviewText}>{selectedProfile.code}</Text></View><Pressable onPress={exportSelected} style={({ pressed }) => [styles.modalButton, pressed && styles.pressed]}><Ionicons name="copy-outline" size={18} color={COLORS.ink} /><Text style={styles.modalButtonText}>نسخ الكود</Text></Pressable></View>}
          {exportMode === "config" && <View style={styles.clipboardPanel}><View style={styles.bigImportIcon}><Ionicons name="document-text-outline" size={28} color={COLORS.accent} /></View><Text style={styles.panelTitle}>تصدير كونفج</Text><Text style={styles.panelBody}>ينشئ {getConfigFilename(selectedProfile.protocol)} بالمحتوى الكامل للسيرفر لمشاركته مع تطبيق VPN آخر.</Text><Pressable onPress={exportSelected} style={({ pressed }) => [styles.modalButton, pressed && styles.pressed]}><Ionicons name="download-outline" size={18} color={COLORS.ink} /><Text style={styles.modalButtonText}>إنشاء ومشاركة الكونفج</Text></Pressable></View>}
          {exportMode === "qr" && <View style={styles.qrPanel}><QrCode value={selectedProfile.code} size={220} /><Text style={styles.qrHint}>هذا الباركود يحتوي كود السيرفر. امسحه من جهاز آخر للاستيراد.</Text><Pressable onPress={copyCode} style={({ pressed }) => [styles.outlineAction, styles.qrCopyButton, pressed && styles.pressed]}><Ionicons name="copy-outline" size={16} color={COLORS.accent} /><Text style={styles.outlineActionText}>نسخ الكود أيضًا</Text></Pressable></View>}
        </View></View>
      </Modal>}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: COLORS.ink }, safeArea: { flex: 1, backgroundColor: COLORS.ink }, content: { paddingHorizontal: 20, paddingTop: 14, paddingBottom: 34, gap: 17 },
  header: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between" }, brandBlock: { flexDirection: "row-reverse", alignItems: "center", gap: 10 }, brandMark: { width: 42, height: 42, borderRadius: 14, backgroundColor: COLORS.accentSoft, alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: "#276A70" }, brandName: { color: COLORS.text, fontSize: 14, fontWeight: "800", letterSpacing: 1.1, textAlign: "right" }, brandCaption: { color: COLORS.muted, fontSize: 10, marginTop: 3, textAlign: "right" }, protocolCount: { alignItems: "center", backgroundColor: COLORS.panel, borderWidth: 1, borderColor: COLORS.border, borderRadius: 13, paddingHorizontal: 10, paddingVertical: 7 }, protocolCountNumber: { color: COLORS.accent, fontSize: 14, fontWeight: "800" }, protocolCountLabel: { color: COLORS.muted, fontSize: 8, marginTop: 2 },
  heroRow: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between", paddingTop: 10 }, heroCopy: { flex: 1, alignItems: "flex-end", gap: 5 }, eyebrow: { color: COLORS.accent, fontSize: 11, fontWeight: "700" }, title: { color: COLORS.text, fontSize: 28, fontWeight: "800", letterSpacing: -0.7, textAlign: "right" }, subtitle: { color: COLORS.muted, fontSize: 13, lineHeight: 20, textAlign: "right" }, contactLink: { width: "100%", minHeight: 50, flexDirection: "row-reverse", alignItems: "center", gap: 8, paddingHorizontal: 10, paddingVertical: 6, marginTop: 3, borderRadius: 14, backgroundColor: "#123D5A", borderWidth: 1, borderColor: "#229ED9" }, contactTelegramIcon: { width: 32, height: 32, borderRadius: 11, backgroundColor: "#229ED9", alignItems: "center", justifyContent: "center" }, contactCopy: { flex: 1, alignItems: "flex-end", gap: 2 }, contactLinkText: { color: "#FFFFFF", fontSize: 11, fontWeight: "900", textAlign: "right" }, contactUsername: { color: "#BDEBFF", fontSize: 9, fontWeight: "700", textAlign: "right" }, heroBadge: { width: 54, height: 54, borderRadius: 18, backgroundColor: COLORS.accentSoft, alignItems: "center", justifyContent: "center", marginLeft: 12 },
  turboCard: { flexDirection: "row-reverse", alignItems: "center", gap: 10, backgroundColor: "#10263A", borderRadius: 17, borderWidth: 1, borderColor: "#23536A", padding: 12 }, turboIcon: { width: 40, height: 40, borderRadius: 13, backgroundColor: COLORS.accentSoft, alignItems: "center", justifyContent: "center" }, turboCopy: { flex: 1, alignItems: "flex-end", gap: 4 }, turboTitle: { color: COLORS.text, fontSize: 12, fontWeight: "800", textAlign: "right" }, turboDescription: { color: COLORS.muted, fontSize: 9, lineHeight: 15, textAlign: "right" }, turboButton: { width: 54, height: 38, borderRadius: 12, backgroundColor: COLORS.accent, alignItems: "center", justifyContent: "center", flexDirection: "row-reverse", gap: 4 }, turboButtonText: { color: COLORS.ink, fontSize: 10, fontWeight: "900" },
  connectionCard: { backgroundColor: COLORS.panel, borderRadius: 25, padding: 19, borderWidth: 1, borderColor: COLORS.border }, connectionCardActive: { borderColor: "#267D73", backgroundColor: "#0D2637" }, cardTopline: { flexDirection: "row-reverse", alignItems: "center", gap: 11 }, statusIcon: { width: 52, height: 52, borderRadius: 18, backgroundColor: "#14253A", alignItems: "center", justifyContent: "center" }, statusIconActive: { backgroundColor: COLORS.accentSoft }, statusCopyBlock: { flex: 1, alignItems: "flex-end" }, cardEyebrow: { color: COLORS.muted, fontSize: 10, marginBottom: 4, textAlign: "right" }, cardTitle: { color: COLORS.text, fontSize: 16, fontWeight: "800", textAlign: "right" }, protocolBadge: { backgroundColor: "#182A40", borderRadius: 8, paddingHorizontal: 8, paddingVertical: 6 }, protocolBadgeActive: { backgroundColor: COLORS.accentSoft }, protocolBadgeText: { color: COLORS.muted, fontSize: 10, fontWeight: "800" }, protocolBadgeTextActive: { color: COLORS.accent }, connectionLine: { height: 1, backgroundColor: COLORS.border, marginVertical: 16 }, cardDescription: { color: COLORS.muted, fontSize: 12, lineHeight: 19, textAlign: "right", marginBottom: 15 }, connectButton: { height: 53, borderRadius: 16, backgroundColor: COLORS.accent, alignItems: "center", justifyContent: "center", flexDirection: "row-reverse", gap: 8 }, disconnectButton: { backgroundColor: "#1A2B42", borderWidth: 1, borderColor: "#2C4661" }, connectButtonText: { color: COLORS.ink, fontSize: 14, fontWeight: "800" }, disconnectButtonText: { color: COLORS.text }, pressed: { opacity: 0.72, transform: [{ scale: 0.985 }] }, serverMetaRow: { flexDirection: "row-reverse", alignItems: "center", gap: 8, backgroundColor: "#10263A", borderRadius: 12, paddingHorizontal: 10, paddingVertical: 8, marginBottom: 14 }, serverFlag: { fontSize: 22 }, serverMetaCopy: { flex: 1, alignItems: "flex-end", gap: 3 }, serverMetaName: { color: COLORS.text, fontSize: 11, fontWeight: "800", textAlign: "right" }, serverMetaHost: { color: COLORS.muted, fontSize: 9, textAlign: "right" }, connectionStats: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-around", marginTop: 17, paddingTop: 15, borderTopWidth: 1, borderTopColor: COLORS.border }, statItem: { alignItems: "center", gap: 4, minWidth: 52 }, statValue: { color: COLORS.text, fontSize: 10, fontWeight: "800" }, statLabel: { color: COLORS.muted, fontSize: 8 }, testAgain: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "center", gap: 6, marginTop: 13 }, testAgainText: { color: COLORS.accent, fontSize: 10, fontWeight: "700" }, statDivider: { width: 1, height: 25, backgroundColor: COLORS.border }, notice: { minHeight: 43, borderRadius: 13, backgroundColor: "#123A39", borderWidth: 1, borderColor: "#276A70", flexDirection: "row-reverse", alignItems: "center", justifyContent: "center", gap: 8, paddingHorizontal: 12 }, noticeText: { color: COLORS.accent, fontSize: 11, fontWeight: "700" },
  sectionHeader: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between", marginTop: 2 }, managerToolbar: { flexDirection: "row-reverse", gap: 7 }, sortChip: { flex: 1, minHeight: 35, borderRadius: 11, backgroundColor: COLORS.panel, borderWidth: 1, borderColor: COLORS.border, flexDirection: "row-reverse", alignItems: "center", justifyContent: "center", gap: 4 }, sortChipActive: { backgroundColor: COLORS.accent, borderColor: COLORS.accent }, sortChipText: { color: COLORS.muted, fontSize: 9, fontWeight: "800" }, sortChipTextActive: { color: COLORS.ink }, bulkActions: { flexDirection: "row-reverse", justifyContent: "flex-start", gap: 9 }, bulkAction: { flexDirection: "row-reverse", alignItems: "center", gap: 4, paddingVertical: 5 }, bulkActionDanger: { color: COLORS.danger, fontSize: 9, fontWeight: "800" }, serverList: { gap: 9 }, serverItem: { backgroundColor: COLORS.panel, borderRadius: 16, borderWidth: 1, borderColor: COLORS.border, padding: 11 }, serverItemSelected: { borderColor: "#2A8B7E", backgroundColor: "#102A3A" }, serverMain: { flexDirection: "row-reverse", alignItems: "center", gap: 8 }, serverStatusDot: { width: 38, height: 38, borderRadius: 12, backgroundColor: COLORS.accentSoft, alignItems: "center", justifyContent: "center" }, serverFlagSmall: { fontSize: 18 }, serverListCopy: { flex: 1, alignItems: "flex-end", gap: 4 }, serverListName: { color: COLORS.text, fontSize: 11, fontWeight: "800", textAlign: "right" }, serverListMeta: { color: COLORS.muted, fontSize: 8, textAlign: "right" }, serverMetrics: { alignItems: "flex-end", gap: 4 }, serverState: { color: COLORS.muted, fontSize: 9, fontWeight: "800" }, serverStateActive: { color: COLORS.accent }, serverStateDead: { color: COLORS.danger }, serverMetricText: { color: COLORS.text, fontSize: 9, fontWeight: "800" }, serverActions: { flexDirection: "row-reverse", gap: 6, marginTop: 10, paddingTop: 9, borderTopWidth: 1, borderTopColor: COLORS.border }, serverAction: { width: 31, height: 29, borderRadius: 9, backgroundColor: "#182B42", alignItems: "center", justifyContent: "center" }, sectionTitle: { color: COLORS.text, fontSize: 15, fontWeight: "800", textAlign: "right" }, sectionHint: { color: COLORS.muted, fontSize: 10, textAlign: "right", marginTop: 3 }, textAction: { color: COLORS.accent, fontSize: 11, fontWeight: "800" }, autoTag: { flexDirection: "row-reverse", alignItems: "center", gap: 4, backgroundColor: "#3A321D", borderRadius: 7, paddingHorizontal: 7, paddingVertical: 5 }, autoTagText: { color: COLORS.warning, fontSize: 9, fontWeight: "800" }, protocolList: { gap: 8, paddingVertical: 2 }, protocolChip: { minHeight: 39, flexDirection: "row-reverse", alignItems: "center", gap: 6, paddingHorizontal: 12, borderRadius: 13, backgroundColor: COLORS.panel, borderWidth: 1, borderColor: COLORS.border }, protocolChipActive: { backgroundColor: COLORS.accent, borderColor: COLORS.accent }, protocolChipText: { color: COLORS.muted, fontSize: 10, fontWeight: "800" }, protocolChipTextActive: { color: COLORS.ink }, importGrid: { flexDirection: "row-reverse", gap: 10 }, importCard: { flex: 1, minHeight: 119, padding: 14, borderRadius: 18, backgroundColor: COLORS.panel, borderWidth: 1, borderColor: COLORS.border, alignItems: "flex-end", gap: 7 }, importIcon: { width: 39, height: 39, borderRadius: 13, alignItems: "center", justifyContent: "center", marginBottom: 2 }, importTitle: { color: COLORS.text, fontSize: 13, fontWeight: "800", textAlign: "right" }, importHint: { color: COLORS.muted, fontSize: 10, textAlign: "right" },
  profileCard: { backgroundColor: COLORS.panel, borderRadius: 19, borderWidth: 1, borderColor: COLORS.border, padding: 14 }, emptyCard: { backgroundColor: COLORS.panel, borderRadius: 19, borderWidth: 1, borderColor: COLORS.border, padding: 20, alignItems: "center", gap: 9 }, emptyIcon: { width: 58, height: 58, borderRadius: 19, backgroundColor: COLORS.accentSoft, alignItems: "center", justifyContent: "center", marginBottom: 2 }, emptyTitle: { color: COLORS.text, fontSize: 14, fontWeight: "800", textAlign: "center" }, emptyBody: { color: COLORS.muted, fontSize: 11, lineHeight: 18, textAlign: "center", maxWidth: 285, marginBottom: 6 }, emptyButton: { minHeight: 42, borderRadius: 13, backgroundColor: COLORS.accent, paddingHorizontal: 16, flexDirection: "row-reverse", alignItems: "center", justifyContent: "center", gap: 7 }, emptyButtonText: { color: COLORS.ink, fontSize: 11, fontWeight: "800" }, profileRow: { flexDirection: "row-reverse", alignItems: "center", gap: 10 }, profileProtocol: { width: 42, height: 42, borderRadius: 14, backgroundColor: COLORS.accentSoft, alignItems: "center", justifyContent: "center" }, profileProtocolText: { color: COLORS.accent, fontWeight: "900", fontSize: 14 }, profileCopy: { flex: 1, alignItems: "flex-end", gap: 5 }, profileName: { color: COLORS.text, fontSize: 13, fontWeight: "800", textAlign: "right" }, profileMeta: { color: COLORS.muted, fontSize: 10, textAlign: "right" }, selectedDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: COLORS.accent }, profileActions: { flexDirection: "row-reverse", gap: 8, marginTop: 13, paddingTop: 12, borderTopWidth: 1, borderTopColor: COLORS.border }, outlineAction: { minHeight: 34, borderRadius: 10, borderWidth: 1, borderColor: COLORS.border, paddingHorizontal: 10, flexDirection: "row-reverse", alignItems: "center", justifyContent: "center", gap: 6 }, outlineActionText: { color: COLORS.accent, fontSize: 10, fontWeight: "800" }, outlineActionTextMuted: { color: COLORS.muted, fontSize: 10, fontWeight: "700" }, profileList: { borderTopWidth: 1, borderTopColor: COLORS.border, marginTop: 13, paddingTop: 10, gap: 6 }, profileOption: { minHeight: 48, borderRadius: 12, paddingHorizontal: 9, flexDirection: "row-reverse", alignItems: "center", gap: 8 }, profileOptionActive: { backgroundColor: "#163344" }, profileOptionCopy: { flex: 1, alignItems: "flex-end", gap: 3 }, profileOptionName: { color: COLORS.text, fontSize: 11, fontWeight: "700" }, profileOptionMeta: { color: COLORS.muted, fontSize: 9 }, tipCard: { flexDirection: "row-reverse", alignItems: "center", gap: 8, borderRadius: 15, backgroundColor: "#1A2636", borderWidth: 1, borderColor: "#2B3A4F", padding: 12 }, tipText: { flex: 1, color: COLORS.muted, fontSize: 10, lineHeight: 16, textAlign: "right" },
  scannerBackdrop: { flex: 1, backgroundColor: "rgba(1, 8, 18, 0.86)", justifyContent: "flex-end" }, scannerSheet: { backgroundColor: "#10243B", borderTopLeftRadius: 29, borderTopRightRadius: 29, paddingHorizontal: 21, paddingTop: 11, paddingBottom: 25, borderWidth: 1, borderColor: COLORS.border }, scannerHint: { color: COLORS.muted, fontSize: 11, lineHeight: 18, textAlign: "right", marginTop: 15, marginBottom: 12 }, cameraFrame: { height: 330, borderRadius: 20, overflow: "hidden", backgroundColor: "#020A14", position: "relative" }, cameraView: { flex: 1 }, scanCorners: { position: "absolute", top: 42, left: 42, right: 42, bottom: 42, borderWidth: 2, borderColor: COLORS.accent, borderRadius: 20 }, cameraPermission: { minHeight: 230, alignItems: "center", justifyContent: "center", gap: 12 }, modalBackdrop: { flex: 1, backgroundColor: "rgba(1, 8, 18, 0.78)", justifyContent: "flex-end" }, modalSheet: { backgroundColor: "#10243B", borderTopLeftRadius: 29, borderTopRightRadius: 29, paddingHorizontal: 21, paddingTop: 11, paddingBottom: 25, borderWidth: 1, borderColor: COLORS.border }, modalHandle: { width: 42, height: 4, borderRadius: 2, backgroundColor: "#44617C", alignSelf: "center", marginBottom: 19 }, modalHeader: { flexDirection: "row-reverse", alignItems: "flex-start", justifyContent: "space-between" }, modalEyebrow: { color: COLORS.accent, fontSize: 10, fontWeight: "700", textAlign: "right", marginBottom: 5 }, modalTitle: { color: COLORS.text, fontSize: 21, fontWeight: "800", textAlign: "right" }, closeButton: { width: 34, height: 34, borderRadius: 12, backgroundColor: "#192E47", alignItems: "center", justifyContent: "center" }, modeTabs: { flexDirection: "row-reverse", gap: 7, backgroundColor: "#0B1A2E", borderRadius: 13, padding: 4, marginTop: 18, marginBottom: 16 }, modeTab: { flex: 1, height: 36, borderRadius: 10, alignItems: "center", justifyContent: "center" }, modeTabActive: { backgroundColor: COLORS.accentSoft }, modeTabText: { color: COLORS.muted, fontSize: 11, fontWeight: "700" }, modeTabTextActive: { color: COLORS.accent }, clipboardPanel: { alignItems: "center", gap: 9, paddingTop: 6 }, bigImportIcon: { width: 62, height: 62, borderRadius: 20, backgroundColor: COLORS.accentSoft, alignItems: "center", justifyContent: "center", marginBottom: 3 }, panelTitle: { color: COLORS.text, fontSize: 15, fontWeight: "800", textAlign: "center" }, panelBody: { color: COLORS.muted, fontSize: 11, lineHeight: 18, textAlign: "center", marginBottom: 10 }, modalButton: { width: "100%", minHeight: 51, borderRadius: 15, backgroundColor: COLORS.accent, alignItems: "center", justifyContent: "center", flexDirection: "row-reverse", gap: 8 }, modalButtonText: { color: COLORS.ink, fontSize: 13, fontWeight: "800" }, inputLabel: { color: COLORS.text, fontSize: 11, fontWeight: "700", textAlign: "right", marginBottom: 8 }, codeInput: { minHeight: 130, borderRadius: 14, backgroundColor: "#0A1A2D", borderWidth: 1, borderColor: COLORS.border, color: COLORS.text, fontSize: 11, lineHeight: 18, padding: 13, textAlignVertical: "top" }, inputHint: { color: COLORS.muted, fontSize: 10, textAlign: "right", marginTop: 8, marginBottom: 14 }, exportName: { color: COLORS.muted, fontSize: 11, textAlign: "right", marginTop: 14 }, codePreview: { minHeight: 98, borderRadius: 14, backgroundColor: "#0A1A2D", borderWidth: 1, borderColor: COLORS.border, padding: 13, marginBottom: 14 }, codePreviewText: { color: COLORS.text, fontSize: 10, lineHeight: 17, textAlign: "left" }, qrPanel: { alignItems: "center", gap: 12 }, qrHint: { color: COLORS.muted, fontSize: 11, textAlign: "center", lineHeight: 17 }, qrCopyButton: { width: "100%" },
});
