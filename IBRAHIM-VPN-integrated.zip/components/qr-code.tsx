import QRCode from "qrcode";
import { useMemo, type ReactElement } from "react";
import { StyleSheet, View } from "react-native";
import Svg, { Rect } from "react-native-svg";

export function QrCode({ value, size = 230 }: { value: string; size?: number }) {
  const matrix = useMemo(() => QRCode.create(value || "IBRAHIM VPN", { errorCorrectionLevel: "M" }).modules, [value]);
  const quiet = 2;
  const total = matrix.size + quiet * 2;
  const cell = size / total;
  const cells: ReactElement[] = [];

  for (let row = 0; row < matrix.size; row += 1) {
    for (let col = 0; col < matrix.size; col += 1) {
      if (matrix.get(row, col)) {
        cells.push(
          <Rect
            key={`${row}-${col}`}
            x={(col + quiet) * cell}
            y={(row + quiet) * cell}
            width={cell + 0.3}
            height={cell + 0.3}
            fill="#071224"
          />,
        );
      }
    }
  }

  return (
    <View style={[styles.frame, { width: size, height: size }]}>
      <Svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        <Rect width={size} height={size} fill="#F3FAFF" />
        {cells}
      </Svg>
    </View>
  );
}

const styles = StyleSheet.create({
  frame: { backgroundColor: "#F3FAFF", padding: 9, borderRadius: 18, overflow: "hidden" },
});
