package space.manus.ibrahimvpn.t236417220387013

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReactContextBaseJavaModule
import com.facebook.react.bridge.ReactMethod
import androidx.core.content.ContextCompat

class IbrahimSingboxModule(private val context: ReactApplicationContext) : ReactContextBaseJavaModule(context) {
  override fun getName() = "IbrahimSingbox"

  @ReactMethod
  fun connect(config: String, promise: Promise) {
    if (config.isBlank()) {
      promise.reject("INVALID_CONFIG", "إعداد VPN فارغ")
      return
    }
    val prepareIntent = VpnService.prepare(context)
    if (prepareIntent != null) {
      val activity: Activity? = currentActivity
      if (activity == null) {
        promise.reject("NO_ACTIVITY", "لا توجد شاشة نشطة لطلب إذن VPN")
        return
      }
      activity.startActivityForResult(prepareIntent, REQUEST_VPN_PERMISSION)
      promise.resolve("permission_required")
      return
    }
    val intent = Intent(context, IbrahimSingboxVpnService::class.java).apply {
      action = IbrahimSingboxVpnService.ACTION_START
      putExtra(IbrahimSingboxVpnService.EXTRA_CONFIG, config)
    }
    ContextCompat.startForegroundService(context, intent)
    promise.resolve("started")
  }

  @ReactMethod
  fun disconnect(promise: Promise) {
    val intent = Intent(context, IbrahimSingboxVpnService::class.java).apply { action = IbrahimSingboxVpnService.ACTION_STOP }
    context.startService(intent)
    promise.resolve(null)
  }

  @ReactMethod
  fun status(promise: Promise) {
    promise.resolve(context.getSharedPreferences(PREFS, 0).getBoolean(KEY_RUNNING, false))
  }

  companion object {
    private const val REQUEST_VPN_PERMISSION = 7012
    const val PREFS = "ibrahim_singbox_state"
    const val KEY_RUNNING = "running"
  }
}
