package space.manus.ibrahimvpn.t236417220387013

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.net.VpnService
import android.os.IBinder
import android.os.ParcelFileDescriptor
import android.util.Log
import io.nekohasekai.libbox.CommandServer
import io.nekohasekai.libbox.CommandServerHandler
import io.nekohasekai.libbox.ConnectionOwner
import io.nekohasekai.libbox.InterfaceUpdateListener
import io.nekohasekai.libbox.Libbox
import io.nekohasekai.libbox.LocalDNSTransport
import io.nekohasekai.libbox.NetworkInterfaceIterator
import io.nekohasekai.libbox.Notification as BoxNotification
import io.nekohasekai.libbox.OverrideOptions
import io.nekohasekai.libbox.PlatformInterface
import io.nekohasekai.libbox.StringIterator
import io.nekohasekai.libbox.TunOptions
import io.nekohasekai.libbox.WIFIState

class IbrahimSingboxVpnService : VpnService() {
  private var tun: ParcelFileDescriptor? = null
  private var commandServer: CommandServer? = null
  private var running = false

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    when (intent?.action) {
      ACTION_STOP -> stopVpn()
      ACTION_START -> startVpn(intent.getStringExtra(EXTRA_CONFIG) ?: "")
    }
    return START_STICKY
  }

  private fun startVpn(config: String) {
    if (config.isBlank() || running) return
    try {
      getSharedPreferences(IbrahimSingboxModule.PREFS, MODE_PRIVATE).edit().putBoolean(IbrahimSingboxModule.KEY_RUNNING, false).apply()
      startForeground(NOTIFICATION_ID, notification("جارٍ تشغيل sing-box"))
      Libbox.setup(io.nekohasekai.libbox.SetupOptions().apply {
        basePath = filesDir.absolutePath
        workingPath = filesDir.absolutePath
        tempPath = cacheDir.absolutePath
        debug = false
      })
      val server = CommandServer(object : CommandServerHandler {
        override fun getSystemProxyStatus() = io.nekohasekai.libbox.SystemProxyStatus()
        override fun serviceReload() = Unit
        override fun serviceStop() = stopVpn()
        override fun setSystemProxyEnabled(enabled: Boolean) = Unit
        override fun writeDebugMessage(message: String) { Log.d(TAG, message) }
      }, Platform())
      server.start()
      server.startOrReloadService(config, OverrideOptions())
      commandServer = server
      running = true
      getSharedPreferences(IbrahimSingboxModule.PREFS, MODE_PRIVATE).edit().putBoolean(IbrahimSingboxModule.KEY_RUNNING, true).apply()
      updateNotification("sing-box متصل")
    } catch (error: Exception) {
      Log.e(TAG, "sing-box failed to start", error)
      stopVpn()
    }
  }

  private inner class Platform : PlatformInterface {
    override fun usePlatformAutoDetectInterfaceControl() = true
    override fun autoDetectInterfaceControl(fd: Int) { protect(fd) }
    override fun useProcFS() = false
    override fun openTun(options: TunOptions): Int {
      val builder = Builder().setSession("IBRAHIM VPN").setMtu(options.mtu)
      val addresses = options.inet4Address
      while (addresses.hasNext()) { val address = addresses.next(); builder.addAddress(address.address(), address.prefix()) }
      val ipv6 = options.inet6Address
      while (ipv6.hasNext()) { val address = ipv6.next(); builder.addAddress(address.address(), address.prefix()) }
      if (options.autoRoute) {
        builder.addRoute("0.0.0.0", 0)
        builder.addRoute("::", 0)
        val dns = options.dnsServerAddress
        while (dns.hasNext()) builder.addDnsServer(dns.next())
      }
      tun?.close()
      tun = builder.establish() ?: error("تعذر إنشاء واجهة TUN")
      return tun!!.fd
    }
    override fun startDefaultInterfaceMonitor(listener: InterfaceUpdateListener) = Unit
    override fun closeDefaultInterfaceMonitor(listener: InterfaceUpdateListener) = Unit
    override fun getInterfaces(): NetworkInterfaceIterator = EmptyNetworkInterfaces()
    override fun clearDNSCache() = Unit
    override fun readWIFIState(): WIFIState? = null
    override fun sendNotification(notification: BoxNotification) = updateNotification(notification.body)
    override fun systemCertificates(): StringIterator = EmptyStrings()
    override fun underNetworkExtension() = false
    override fun includeAllNetworks() = false
    override fun findConnectionOwner(ipProtocol: Int, sourceAddress: String, sourcePort: Int, destinationAddress: String, destinationPort: Int): ConnectionOwner = ConnectionOwner()
    override fun localDNSTransport(): LocalDNSTransport? = null
  }

  private class EmptyStrings : StringIterator {
    override fun len() = 0
    override fun hasNext() = false
    override fun next() = ""
  }
  private class EmptyNetworkInterfaces : NetworkInterfaceIterator {
    override fun hasNext() = false
    override fun next() = io.nekohasekai.libbox.NetworkInterface()
  }

  private fun stopVpn() {
    getSharedPreferences(IbrahimSingboxModule.PREFS, MODE_PRIVATE).edit().putBoolean(IbrahimSingboxModule.KEY_RUNNING, false).apply()
    try { commandServer?.closeService() } catch (_: Exception) {}
    try { commandServer?.close() } catch (_: Exception) {}
    commandServer = null
    try { tun?.close() } catch (_: Exception) {}
    tun = null
    running = false
    stopForeground(STOP_FOREGROUND_REMOVE)
    stopSelf()
  }

  private fun notification(text: String): Notification {
    val manager = getSystemService(NotificationManager::class.java)
    manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "IBRAHIM VPN", NotificationManager.IMPORTANCE_LOW))
    return Notification.Builder(this, CHANNEL_ID).setContentTitle("IBRAHIM VPN").setContentText(text).setSmallIcon(android.R.drawable.stat_sys_warning).setOngoing(true).build()
  }
  private fun updateNotification(text: String) { getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification(text)) }
  override fun onDestroy() { stopVpn(); super.onDestroy() }
  override fun onBind(intent: Intent?): IBinder? = super.onBind(intent)

  companion object {
    const val ACTION_START = "space.manus.ibrahimvpn.START_SINGBOX"
    const val ACTION_STOP = "space.manus.ibrahimvpn.STOP_SINGBOX"
    const val EXTRA_CONFIG = "singbox_config"
    private const val CHANNEL_ID = "ibrahim_singbox"
    private const val NOTIFICATION_ID = 7402
    private const val TAG = "IbrahimSingbox"
  }
}
